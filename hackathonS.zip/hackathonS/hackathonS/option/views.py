from django.shortcuts import render

# Create your views here.
def options(request):
    return render(request,'option/options.html')