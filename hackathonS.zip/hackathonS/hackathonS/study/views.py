from django.shortcuts import render,redirect
from django.core.files.storage import FileSystemStorage
from .form import BookForm
from .models import Book
from django.views.generic import CreateView
# Create your views here.
def studyhome(request):
    return render(request, 'study/home.html')

def upload(request):
    context = {}
    if request.method == 'POST':
        uploaded_file = request.FILES['document']
        fs = FileSystemStorage()
        name = fs.save(uploaded_file.name, uploaded_file)
        context['url'] = fs.url(name)
    return render(request, 'study/upload.html', context)

def delete_book(request,pk):
    if request.method == 'POST':
        book = Book.objects.get(pk=pk)
        book.delete()
    return redirect('book-list')

def book_list(request):
    books = Book.objects.all()
    print(books)
    context = {'books':books}
    return render(request,'study/book_list.html',context)

class UploadCreateView(CreateView):
    model = Book
    template_name = 'study/upload_book.html'
    fields = ['title','body','pdf']
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super(UploadCreateView, self).form_valid(form)


def upload_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm()
    return render(request,'study/upload_book.html',{'form':form})